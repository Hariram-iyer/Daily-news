# Daily News — Android MVP source project

A native Android (Kotlin + Jetpack Compose) starter app and a small Python backend. The app lets a user select an English newspaper PDF, sends it to the backend, and displays extracted stories as horizontally swipeable cards with quick and detailed reading modes.

## Important status

This is an MVP source project, not a signed/installable APK. The current execution environment does not include the Android SDK or Gradle, so an APK could not be built or device-tested here. The project is structured to open in Android Studio.

## Architecture

- `app/`: Android app (PDF picker, upload, swipe cards, quick/detailed view, session bookmarks).
- `backend/`: FastAPI service; extracts selectable PDF text page-by-page and asks an AI model to structure articles.
- API credentials stay on the backend. Never embed an AI API key in the Android application.

## Run the backend locally

Requires Python 3.11+.

```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
export OPENAI_API_KEY="your-key"   # PowerShell: $env:OPENAI_API_KEY="your-key"
uvicorn main:app --host 0.0.0.0 --port 8000
```

Check `http://localhost:8000/health`.

## Run the Android app

1. Open the `daily-news-android` folder in Android Studio (recent stable version).
2. Allow Gradle sync and install the Android SDK platform 35 if prompted.
3. Run on an Android emulator or physical device.
4. For the Android emulator, the default backend URL `http://10.0.2.2:8000` points to the host machine.
5. For a physical phone, enter the computer's LAN IP and ensure both devices are on the same network. For production, deploy the backend behind HTTPS and use that HTTPS URL.

## Current limitations / next development items

1. **Scanned PDFs:** the current backend requires selectable text. OCR is not yet integrated. It deliberately returns an error instead of guessing when a scan has no text layer.
2. **Original-page view:** page numbers are attached to each article, but an in-app PDF page viewer/deep-link is not yet implemented.
3. **Persistence:** bookmarks currently live only for the current app session. A database and reading history are next steps.
4. **Date entry:** backend accepts `publication_date`; the initial Android screen currently defaults to today's date. Add a date picker before production.
5. **Accuracy controls:** backend requires an exact verbatim evidence quote from the source page and drops stories without one. This is a useful guardrail, not a guarantee of perfect semantic fidelity. Human review and side-by-side source display should be added before relying on summaries.
6. **Article layout:** newspaper page extraction can mix columns and sidebars. Production-grade layout detection and OCR are required for many publisher PDFs.
7. **Security:** add authentication, upload quotas, HTTPS, retention/deletion controls, and private storage before public deployment.

## API

`POST /process` multipart form fields:
- `file`: PDF file
- `newspaper_name`: optional newspaper title
- `publication_date`: optional ISO date (`YYYY-MM-DD`)

`GET /health`: backend health check.

## Build an APK using GitHub Actions

This project includes `.github/workflows/build-apk.yml`. To build an installable debug APK without installing Android Studio locally:

1. Create a private GitHub repository and upload the contents of this project.
2. Open the repository's **Actions** tab and enable workflows if prompted.
3. Select **Build Daily News APK** and choose **Run workflow** (or push to `main`).
4. When the run completes, open it and download the `daily-news-debug-apk` artifact.
5. Extract the artifact; install `app-debug.apk` on your Android phone. Android may ask you to allow installation from that source.

The APK is a debug build, suitable for personal testing, not Play Store release. The PDF-processing backend must also be deployed and reachable over HTTPS for real newspaper processing. Do not expose your AI API key in the Android app.
