import json
import os
import re
import uuid
from datetime import date
from typing import Any

import fitz  # PyMuPDF
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from openai import OpenAI

app = FastAPI(title="Daily News PDF Processor", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

MODEL = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")
MAX_CHARS_PER_PAGE = 14000

@app.get("/health")
def health():
    return {"status": "ok", "model": MODEL}


def parse_json(text: str) -> dict[str, Any]:
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.I)
    return json.loads(text)


def extract_page_articles(client: OpenAI, page_text: str, page_no: int, newspaper: str, pub_date: str) -> list[dict[str, Any]]:
    prompt = f'''Extract distinct substantive news articles from the newspaper page text below.
Return ONLY valid JSON: {{"articles": [{{"category":"...","headline":"...","summary":"...","why_it_matters":"...","detail":"...","evidence_quote":"..."}}]}}.
Rules:
- Use ONLY information explicitly present in this page text. Do not use outside knowledge, browsing, assumptions, or invented context.
- Preserve the article's meaning, qualifications, numbers, names, dates, attribution, and uncertainty.
- Keep the original headline when clearly available. If no reliable headline is present, create a neutral headline faithful to the text.
- summary: 3 to 5 concise sentences. detail: 2 to 4 paragraphs, with no added facts.
- why_it_matters: explain only implications actually stated or directly supported by the article; otherwise say "The article does not state a specific implication."
- evidence_quote: copy one continuous exact sentence or phrase from the page text that supports the article. It must be verbatim.
- Exclude advertisements, puzzles, listings, and duplicate snippets. Do not combine unrelated stories.
- Categories must be one of: Business & Economy, Taxation, Corporate Affairs, India, International, Technology, Sports, Entertainment, Other.
- If the page contains no identifiable news article, return an empty articles array.
Newspaper: {newspaper}; publication date: {pub_date}; page: {page_no}.
PAGE TEXT:
{page_text[:MAX_CHARS_PER_PAGE]}'''
    response = client.responses.create(model=MODEL, input=prompt)
    payload = parse_json(response.output_text)
    output = []
    for item in payload.get("articles", []):
        quote = str(item.get("evidence_quote", "")).strip()
        # Conservative source-integrity check: reject summaries without an exact source anchor.
        if len(quote) < 12 or quote not in page_text:
            continue
        headline = str(item.get("headline", "")).strip()
        summary = str(item.get("summary", "")).strip()
        detail = str(item.get("detail", "")).strip()
        if not headline or not summary or not detail:
            continue
        output.append({
            "id": str(uuid.uuid4()),
            "category": str(item.get("category", "Other")),
            "headline": headline,
            "summary": summary,
            "why_it_matters": str(item.get("why_it_matters", "The article does not state a specific implication.")),
            "detail": detail,
            "newspaper": newspaper,
            "date": pub_date,
            "page": page_no,
            "evidence_quote": quote,
        })
    return output


@app.post("/process")
async def process_pdf(
    file: UploadFile = File(...),
    newspaper_name: str = Form("Uploaded newspaper"),
    publication_date: str = Form(default_factory=lambda: date.today().isoformat()),
):
    if file.content_type not in ("application/pdf", "application/octet-stream") and not (file.filename or "").lower().endswith(".pdf"):
        raise HTTPException(400, "Please upload a PDF file.")
    raw = await file.read()
    if not raw.startswith(b"%PDF"):
        raise HTTPException(400, "The uploaded file does not appear to be a valid PDF.")
    if len(raw) > 80 * 1024 * 1024:
        raise HTTPException(413, "PDF is larger than the 80 MB upload limit.")
    try:
        doc = fitz.open(stream=raw, filetype="pdf")
    except Exception as exc:
        raise HTTPException(400, f"Could not open PDF: {exc}")
    if len(doc) > 250:
        raise HTTPException(400, "Please split newspapers longer than 250 pages.")
    pages = [(i + 1, page.get_text("text").strip()) for i, page in enumerate(doc)]
    doc.close()
    if not any(text for _, text in pages):
        raise HTTPException(422, "No selectable text was found. This looks like a scanned PDF; OCR support is required before it can be processed reliably.")
    if not os.getenv("OPENAI_API_KEY"):
        raise HTTPException(503, "Backend is missing OPENAI_API_KEY. Set it in the backend environment; never put it in the Android app.")
    client = OpenAI()
    articles = []
    for page_no, text in pages:
        if not text:
            continue
        try:
            articles.extend(extract_page_articles(client, text, page_no, newspaper_name.strip() or "Uploaded newspaper", publication_date))
        except Exception as exc:
            # Do not silently fabricate or return partial unverified content for a failed page.
            raise HTTPException(502, f"AI extraction failed on page {page_no}: {exc}")
    return {"newspaper": newspaper_name, "date": publication_date, "page_count": len(pages), "articles": articles}
