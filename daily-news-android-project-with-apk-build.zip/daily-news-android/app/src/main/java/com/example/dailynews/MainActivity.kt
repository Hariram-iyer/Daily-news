package com.example.dailynews

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DailyNewsScreen() }
    }
}

data class NewsItem(
    val id: String, val category: String, val headline: String,
    val summary: String, val whyItMatters: String, val detail: String,
    val newspaper: String, val date: String, val page: Int
)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun DailyNewsScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var serverUrl by remember { mutableStateOf("http://10.0.2.2:8000") }
    var newspaperName by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Upload an English newspaper PDF to begin.") }
    var loading by remember { mutableStateOf(false) }
    var items by remember { mutableStateOf(listOf<NewsItem>()) }
    var showDetails by remember { mutableStateOf(false) }
    var bookmarks by remember { mutableStateOf(setOf<String>()) }
    var selectedUri by remember { mutableStateOf<Uri?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            selectedUri = uri
            scope.launch {
                loading = true
                status = "Reading PDF and extracting articles…"
                try {
                    val result = withContext(Dispatchers.IO) {
                        val input = context.contentResolver.openInputStream(uri) ?: error("Cannot open selected PDF")
                        val file = File(context.cacheDir, "newspaper-upload.pdf")
                        input.use { src -> file.outputStream().use { dst -> src.copyTo(dst) } }
                        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
                            .addFormDataPart("newspaper_name", newspaperName.ifBlank { "Uploaded newspaper" })
                            .addFormDataPart("file", file.name, file.asRequestBody("application/pdf".toMediaType()))
                            .build()
                        val request = Request.Builder().url(serverUrl.trimEnd('/') + "/process").post(body).build()
                        OkHttpClient().newCall(request).execute().use { response ->
                            val text = response.body?.string().orEmpty()
                            if (!response.isSuccessful) error("Server error ${response.code}: $text")
                            JSONObject(text)
                        }
                    }
                    val array = result.getJSONArray("articles")
                    items = (0 until array.length()).map { i -> array.getJSONObject(i).toNewsItem() }
                    status = "${items.size} articles extracted. Swipe to read."
                } catch (e: Exception) {
                    status = "Could not process PDF: ${e.message}. Check that the backend is running and the server address is correct."
                } finally { loading = false }
            }
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF173B57), background = Color(0xFFF4F6F8))) {
        Scaffold(topBar = {
            TopAppBar(title = { Text("Daily News", fontWeight = FontWeight.Bold) },
                actions = { Text("${items.size} stories  ", color = MaterialTheme.colorScheme.primary) })
        }) { padding ->
            Column(Modifier.fillMaxSize().background(Color(0xFFF4F6F8)).padding(padding).padding(16.dp)) {
                OutlinedTextField(value = newspaperName, onValueChange = { newspaperName = it },
                    label = { Text("Newspaper name (e.g. Mint)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = serverUrl, onValueChange = { serverUrl = it },
                    label = { Text("Backend URL") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Spacer(Modifier.height(10.dp))
                Button(onClick = { picker.launch(arrayOf("application/pdf")) }, enabled = !loading,
                    modifier = Modifier.fillMaxWidth()) { Text(if (loading) "Processing…" else "＋ Upload newspaper PDF") }
                Text(status, style = MaterialTheme.typography.bodySmall, color = Color.DarkGray, modifier = Modifier.padding(vertical = 10.dp))
                if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
                if (items.isNotEmpty()) {
                    val pager = rememberPagerState(pageCount = { items.size })
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("${pager.currentPage + 1} / ${items.size}", fontWeight = FontWeight.SemiBold)
                        TextButton(onClick = { showDetails = !showDetails }) { Text(if (showDetails) "Quick read" else "Detailed read") }
                    }
                    HorizontalPager(state = pager, modifier = Modifier.weight(1f).fillMaxWidth(), pageSpacing = 14.dp) { page ->
                        val article = items[page]
                        Card(Modifier.fillMaxSize(), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text(article.category.uppercase(), color = Color(0xFF47718E), fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                                Text(article.headline, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                                HorizontalDivider()
                                Text(if (showDetails) "FULLER COVERAGE" else "QUICK READ", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Gray)
                                Text(if (showDetails) article.detail else article.summary, style = MaterialTheme.typography.bodyLarge)
                                Text("WHY IT MATTERS", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Gray)
                                Text(article.whyItMatters, style = MaterialTheme.typography.bodyMedium)
                                Spacer(Modifier.weight(1f))
                                Text("${article.newspaper}  •  ${article.date}  •  Page ${article.page}", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                OutlinedButton(onClick = { bookmarks = if (article.id in bookmarks) bookmarks - article.id else bookmarks + article.id }, modifier = Modifier.fillMaxWidth()) {
                                    Text(if (article.id in bookmarks) "★ Bookmarked" else "☆ Bookmark")
                                }
                            }
                        }
                    }
                    Text("Swipe horizontally for previous / next story", style = MaterialTheme.typography.labelSmall, color = Color.Gray, modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 8.dp))
                } else if (!loading) {
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text("Your newspaper stories will appear here", color = Color.Gray)
                    }
                }
            }
        }
    }
}

private fun JSONObject.toNewsItem() = NewsItem(
    id = optString("id"), category = optString("category", "Other"),
    headline = optString("headline"), summary = optString("summary"),
    whyItMatters = optString("why_it_matters"), detail = optString("detail"),
    newspaper = optString("newspaper"), date = optString("date"), page = optInt("page", 1)
)
